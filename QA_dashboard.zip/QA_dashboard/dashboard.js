$('.selectpicker').selectpicker();
var globalObj={};
var transNameArray = [];
var excelData = [];
var baseLineData = [];
var MacroLevelDataArray = [];
var MacroLevelDataObj;
var selectedMonthsArray =[];
var varianceArray =[];
var monthsData =["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
var fullmonthsData =["January","February","March","April","May","June","July","August","September","October","November","December"];
var monthDataObj = {};
var currentTransName = "";
var selectedGraph = '';
var accordionDataArray = [];
var chartDataArray = [   
   
];
var MacroLevelDataArray =[
  
];

$(document).ready(function() {
    selectedGraph = $('#selectGraph').val();
    $('#transMenuDiv .panel-body div').click(function () {
        if($('#selectGraph').val() == "Graph-2"){
            $('.showActive').removeClass('showActive');
            $('.panel-heading').removeClass('showActive');
            $(this).addClass('showActive');
            $('.panel-heading#heading-'+$(this).parent().parent().attr('id').split('-')[1]).addClass('showActive');
            
            google.charts.load('current', {
                callback: function () {
                  drawChartTrans();
                },
                packages: ['corechart']
              });
        }
        
      });
  })

  function drawChart() {
    
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Month');
    data.addColumn('number', 'Percentage');  
    data.addColumn({type: 'string', role: 'tooltip', 'p': {'html': true}});
    
    data.addRows(MacroLevelDataArray);
    
    var options = {
      tooltip: {isHtml: true},
        title: "Macro Level Status Graph",
        width: '90%',
        height: 565,
        hAxis: {                        
            title:'Month',titleTextStyle: {color: '#933'},            
            },
        vAxis: {         
            title:'Percentage',titleTextStyle: {color: '#993'},            
            minValue: 0
        },
        chart: {
          title: 'Performance Test Graph',
          subtitle: 'in seconds'  ,          
        },
      chartArea: {
        // adjust chart area size
        left: '10%',
        top: '15%',   
        height: '70%',
        width: '90%'
        //backgroundColor: 'magenta'
    } ,
      legend:{position:'none'}
    };
    
    var chart = new google.visualization.LineChart(document.getElementById('graphmainDiv'));
    
    chart.draw(data, options);
    }

    function drawChartTrans() {
    
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Month');
        data.addColumn('number', 'Seconds');  
       data.addColumn({type: 'string', role: 'tooltip', 'p': {'html': true}});
        
        data.addRows(chartDataArray);
        
        var options = {
          tooltip: {isHtml: true},
            title: currentTransName,
            width: '90%',
            height: 565,
            hAxis: {                        
                title:'Month',titleTextStyle: {color: '#933'},            
                },
            vAxis: {         
                title:'Seconds',titleTextStyle: {color: '#993'},            
                minValue: 0
            },
            chart: {
              title: 'Performance Test Graph',
              subtitle: 'in seconds'  ,          
            },
          chartArea: {
            // adjust chart area size
            left: '10%',
            top: '15%',   
            height: '70%',
            width: '90%'
            //backgroundColor: 'magenta'
        } ,
          legend:{position:'none'}
        };
        
        var chart = new google.visualization.LineChart(document.getElementById('graphmainDiv'));
        
        chart.draw(data, options);
        }

function generateGraph(){
    google.charts.load('current', {
        callback: function () {
          drawChart();
        },
        packages: ['corechart']
      });
}

generateGraph();

function changeGraph(){
    selectedGraph  = $('#selectGraph').val();
    if($('#selectGraph').val() == "Graph-1"){
        google.charts.load('current', {
            callback: function () {
              drawChart();
            },
            packages: ['corechart']
          });
    }else{
        google.charts.load('current', {
            callback: function () {
                drawChartTrans();
            },
            packages: ['corechart']
          });
    }
}



function generateData(){
  $('#transParentDiv').addClass('hideContent');
  $('#graphParentDiv').addClass('hideContent');
  $('#footerNote').addClass('hideContent');
  MacroLevelDataArray = [];chartDataArray =[];
  $("#month-select").val([]);
  enableFilter();
  google.charts.load('current', {
    callback: function () {
      drawChartTrans();
    },
    packages: ['corechart']
  });
  google.charts.load('current', {
    callback: function () {
      drawChart();
    },
    packages: ['corechart']
  });
  fetchExcelData(); 
    
}


function fetchExcelData(){
  var excelFileName = $('#appName :selected').val();  
if(excelFileName !=='select' ){
  var url = "/"+excelFileName+".xlsx";
  
  //url = "/DashboardReport.xlsx";

  var oReq = new XMLHttpRequest();
  oReq.open("GET", url, true);
  oReq.responseType = "arraybuffer";

  oReq.onload = function(e) {
      var arraybuffer = oReq.response;

      /* convert data to binary string */
      var data = new Uint8Array(arraybuffer);

      var arr = new Array();
      for (var i = 0; i != data.length; ++i) {
          arr[i] = String.fromCharCode(data[i]);
      }

      var bstr = arr.join("");

      var cfb = XLSX.read(bstr, { type: 'binary' });

      // cfb.SheetNames.forEach(function(sheetName, index) {

      //     // Obtain The Current Row As CSV
      //     var fieldsObjs = XLS.utils.sheet_to_json(cfb.Sheets[sheetName]);
      //     console.log(fieldsObjs);
      //     fieldsObjs.map(function(field) {
      //         console.log('field.Fields');
      //         $("#my_file_output").append('<input type="checkbox" value="' + field.Fields + '">' + field.Fields + '<br>');
      //     });

      // });       
          excelData =  XLS.utils.sheet_to_json(cfb.Sheets["Sheet1"]).slice();          
          MacroLevelDataObj = excelData.shift();
          baseLineData =  XLS.utils.sheet_to_json(cfb.Sheets["Sheet2"]).slice();
          // baseLineData = baseLineData.map(function(item){
          //   delete item['Transaction Name'] 
          //       return item; 
          //   })
          accordionDataArray = [];

          montharr = Object.keys(excelData[0]);
          montharr.shift();montharr.shift();
          $('#month-select').html('');
          montharr =  montharr.map(function(val){
            tempData = monthsData[new Date(val).getMonth()];
            tempData += ' '+ (new Date(val).getFullYear());
            monthDataObj[tempData] = val;             
            $(".selectpicker").append('<option>'+tempData+'</option>');
            return tempData;
          })

       $("#month-select").removeAttr("disabled");
      $('.selectpicker').selectpicker('refresh');
        transNameArray = [];
        tnsgrpArray = [];     basetnsgrpArray = [];               
        excelData.forEach(function(element, ind){                
          var tempParent = '';var basetempParent = '';
            transNameArray.push(element['Transaction Name']);

            tempgrpArray =  element['Transaction Name'].split('_');
          if(tempgrpArray.length > 4){
            tempParent = tempgrpArray[0]+'_'+tempgrpArray[1]+'_'+tempgrpArray[2];  
          }else{
            tempParent = tempgrpArray[0]+'_'+tempgrpArray[1];  
          }
          parentIndex = tnsgrpArray.indexOf(tempParent)
          if(parentIndex == -1){
            tnsgrpArray.push(tempParent);
          }
          parentIndex = tnsgrpArray.indexOf(tempParent);

          basetempgrpArray  = baseLineData[ind]['Transaction Name'].split('_');
          if(basetempgrpArray.length > 4){
            basetempParent = basetempgrpArray[0]+'_'+basetempgrpArray[1]+'_'+basetempgrpArray[2];  
          }else{
            basetempParent = basetempgrpArray[0]+'_'+basetempgrpArray[1];  
          }
          baseparentIndex = basetnsgrpArray.indexOf(basetempParent)
          if(baseparentIndex == -1){
            basetnsgrpArray.push(basetempParent);
          }
          baseparentIndex = basetnsgrpArray.indexOf(basetempParent);
          delete baseLineData[ind]['Transaction Name'];
          

            if(accordionDataArray[parentIndex] == undefined){
              accordionDataArray[parentIndex] = {};
              accordionDataArray[parentIndex]['name'] = tempParent;
              accordionDataArray[parentIndex]['data'] = [];
            }    
            var tempElementObj
            if(parentIndex == baseparentIndex){
              tempElementObj = Object.assign(element,baseLineData[ind]);
            }else{
              tempElementObj = element;
            }
            accordionDataArray[parentIndex]['data'].push(tempElementObj);          
        });       
                     
  }

  oReq.send();
}else{
  $('#change-chart').attr("disabled","disabled");
  $("#month-select").html('');
  $("#month-select").attr("disabled","disabled");
  $('.selectpicker').selectpicker('refresh');
}

}



function enableFilter(){
  selectedMonthsArray = $("#month-select").val();
  if(selectedMonthsArray.length==0){
    $('#change-chart').attr("disabled","disabled");
  }else{
    $('#change-chart').removeAttr("disabled");
  }
}


function populateData(){
  MacroLevelDataArray = [];
  var tempText = '';
  var macroFlag = 0;
  $('#selectGraph').val('Graph-1');
  $('.hideContent').removeClass('hideContent');



  tempText+= '<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">';
  

  for(var i=0;i<accordionDataArray.length;i++){
      tempText += '<div class="panel panel-default">'+
      '<div class="panel-heading" role="tab" id="heading-'+(i+1)+'">'+
      '<h4 class="panel-title">'+
      '<span>'+
      '<a  role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-'+(i+1)+'" aria-expanded="false" aria-controls="collapse-'+(i+1)+'">'+
        accordionDataArray[i]['name']+
      '</a>'+
      '</span>'+
      '</h4>'+
      '</div>'+
      '<div id="collapse-'+(i+1)+'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-'+(i+1)+'">'+
      '<div class="panel-body">';

      
        for(var j = 0;j<accordionDataArray[i]['data'].length; j++){
          temppriority = accordionDataArray[i]['data'][j]['Priority'];
          if(temppriority == "Low"){
            divColor = 'rgb(85, 194, 85)';
          }else if(temppriority == "Medium"){
            divColor = 'rgb(253, 225, 65)';
          }else{
            divColor = 'rgb(255, 39, 39)';
          }
          tnsName = accordionDataArray[i]['data'][j]['Transaction Name']
          tempText +=    '<div style="border: 4px solid '+divColor+';" title="'+tnsName+'">'+tnsName+'</div>';

          globalObj[accordionDataArray[i]['data'][j]['Transaction Name']] = [];
          for(k =0; k< selectedMonthsArray.length;k++){
            tempMonthIndex = monthsData.indexOf(selectedMonthsArray[k].split(' ')[0]);
            tempBaseKey = fullmonthsData[tempMonthIndex];
            baseLine_1 = (accordionDataArray[i]['data'][j][tempBaseKey+'_BL1']? accordionDataArray[i]['data'][j][tempBaseKey+'_BL1'] :"NA");
            baseLine_2 = (accordionDataArray[i]['data'][j][tempBaseKey+'_BL2']? accordionDataArray[i]['data'][j][tempBaseKey+'_BL2'] :"NA");
            baseLine_3 = (accordionDataArray[i]['data'][j][tempBaseKey+'_BL3']? accordionDataArray[i]['data'][j][tempBaseKey+'_BL3'] :"NA");
            tempKey = monthDataObj[[selectedMonthsArray[k]]];
            tempvalue = accordionDataArray[i]['data'][j][tempKey].split('(')[0];
            tempVariance =  ((accordionDataArray[i]['data'][j][tempKey].split('(')[1]))?((accordionDataArray[i]['data'][j][tempKey].split('(')[1]))?.split(')')[0] : "NA";
            if(tempVariance.indexOf('-')>-1){
              varianceHtmlText = '<strong style="color:red !important;">'+tempVariance+'</strong>';
            }else if(tempVariance  ==  'NA'){
              varianceHtmlText = '<strong style="color:black !important;">'+tempVariance+'</strong>';
            }else{
              varianceHtmlText = '<strong style="color:green !important;">'+tempVariance+'</strong>';
            }
            tempMonthVal = selectedMonthsArray[k] ; tempDataVal = Number(tempvalue);
            temptoolval= '<div class="tooltipStyle"><strong>'+selectedMonthsArray[k]+'</strong><br>Seconds: <strong>'+tempvalue+'</strong><br>Variance: '+varianceHtmlText+'<br>'+
            'Base_Line-1 : <strong>'+baseLine_1+'</strong><br>Base_Line-2 : <strong>'+baseLine_2+'</strong><br>Base_Line-3 : <strong>'+baseLine_3+'</strong><br></div>';
            globalObj[accordionDataArray[i]['data'][j]['Transaction Name']].push([tempMonthVal,tempDataVal, temptoolval]);            
            if(macroFlag == 0){
              tempmacroKey   = monthDataObj[[selectedMonthsArray[k]]];
              tempmacroValue = MacroLevelDataObj[tempmacroKey].split('%')[0];
              MacroLevelDataArray.push([selectedMonthsArray[k],Number(tempmacroValue), '<div class="tooltipStyle"><strong>'+selectedMonthsArray[k]+'</strong><br>Percent: <strong>'+tempmacroValue+' %'+'</strong></div>']);              
              console.log(MacroLevelDataArray);
              }
          }
          macroFlag++;
        }
        

      tempText +='</div>'+
      '</div>'+
      '</div>';     
      
  }
  tempText += '</div>';
  console.log(tempText);
  $('#transMenuDiv').html(tempText);
  $('#transMenuDiv .panel-body div').click(function () {
    if($('#selectGraph').val() == "Graph-2"){
        $('.showActive').removeClass('showActive');
        $('.panel-heading').removeClass('showActive');
        $(this).addClass('showActive');
        $('.panel-heading#heading-'+$(this).parent().parent().attr('id').split('-')[1]).addClass('showActive');

        let fName = $(this).attr('title');
        currentTransName = fName;
          chartDataArray = globalObj[fName];

        google.charts.load('current', {
            callback: function () {
              drawChartTrans();
            },
            packages: ['corechart']
          });
          
    }
    
  });

  google.charts.load('current', {
      callback: function () {
        drawChart();
      },
      packages: ['corechart']
    });
  $('#bodyDiv').removeClass('hide');

    
}


function dataGrouping() {

  

}